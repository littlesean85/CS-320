package ContactApp;

public class ContactClass {
	private static final int ContactPhoneNumberLegnth = 10;
	private static final byte ContactCustIDLength = 10;
	private static final byte ContactFirstNameLength = 10;
	private static final byte ContactLastNameLength = 10;
	private static final byte ContactHomeAddressLength = 30;
	private static final String Initialize = "Initial";
	private static final String InitializeNumber = "1234567789";
	private String custId;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String homeAddress;
	
	ContactClass(){
		this.custId = Initialize;
		this.firstName = Initialize;
		this.lastName = Initialize;
		this.phoneNumber = InitializeNumber;
		this.homeAddress = Initialize;
	}
	
	ContactClass(String custId){
		updateCustId(custId);
		this.firstName = Initialize;
		this.lastName = Initialize;
		this.phoneNumber = InitializeNumber;
		this.homeAddress = Initialize;
	}
	
	ContactClass(String custId, String firstName){
		updateCustId(custId);
		updateFirstName(firstName);
		this.lastName = Initialize;
		this.phoneNumber = InitializeNumber;
		this.homeAddress = Initialize;
	}
	
	ContactClass(String custId, String firstName, String lastName){
		updateCustId(custId);
		updateFirstName(firstName);
		updateLastName(lastName);
		this.phoneNumber = InitializeNumber;
		this.homeAddress = Initialize;
	}
	
	ContactClass(String custId, String firstName, String lastName, String phoneNumber){
		updateCustId(custId);
		updatefirstName(firstName);
		updatelastName(lastName);
		updatePhoneNumber(phoneNumber);
		this.homeAddress = Initialize;
	}
	
	ContactClass(String custId, String firstName, String lastName, String phoneNumber, String homeAddress){
		updateCustId(custId);
		updatefirstName(firstName);
		updatelastName(lastName);
		updatePhoneNumber(phoneNumber);
		updateHomeAddress(homeAddress);
	}
	
	protected final String getCustId() {
		return custId;
	}
	
	protected final String getFirstName() {
		return firstName;
	}
	
	protected final String getLastName() {
		return lastName;
	}
	
	protected final String getPhoneNumber() {
		return phoneNumber;
	}
	
	protected final String getHomeAddress() {
		return homeAddress;
	}
	
	protected void updateFirstName(String firstName) {
		if(firstName == null) {
			throw new IllegalArgumentException("First Name must not be empty");
			
		}
		
		else if(firstName.length() > ContactFirstNameLength) {
			throw new IllegalArgumentException("First name must not be longer than " + ContactFirstNameLength + " characters.");
		}
		
		else {
			this.firstName = firstName;
		}
	}
	
	protected void updateLastName(String lastName) {
		if(lastName == null) {
			throw new IllegalArgumentException("Last name must not be empty.");
		}
		else if(lastName.length() > ContactLastNameLength) {
			throw new IllegalArgumentException("Last name must not be longer than " + ContactLastNameLength + " characters.");
		}
		
		else {
			this.lastName = lastName;
		}
	}
	
	protected void updatePhoneNumber(String phoneNumber) {
		String regex = "[0-9]+";
		if(phoneNumber == null) {
			throw new IllegalArgumentException("Phone number must not be empty");
		}
		
		else if(phoneNumber.length() != ContactPhoneNumberLegnth) {
			throw new IllegalArgumentException("Phone Number length is invalid.  It must be " + ContactPhoneNumberLegnth + " digits.");
		}
		
		else if(!phoneNumber.matches(regex)) {
			throw new IllegalArgumentException("Phone Number can only be numbers.");
		}
		
		else {
			this.phoneNumber = phoneNumber;
		}
	}
	
	protected void updateHomeAddress(String homeAddress) {
		if(homeAddress == null) {
			throw new IllegalArgumentException("Home Address must not be empty.");
		}
		
		else if(homeAddress.length() > ContactHomeAddressLength) {
			throw new IllegalArgumentException("Address must not be longer than " + ContactHomeAddressLength + " characters.");
		}
		
		else {
			this.homeAddress = homeAddress;
		}
	}
	
	protected void updateCustId(String custId) {
		if(custId == null) {
			throw new IllegalArgumentException("Customer ID must not be empty.");
		}
		
		else if(custId.length() > ContactCustIDLength) {
			throw new IllegalArgumentException("Customer ID must not be longer than " + ContactCustIDLength + " characters.");
		}
		
		else {
			this.custId = custId;
		}
	}
	

}
