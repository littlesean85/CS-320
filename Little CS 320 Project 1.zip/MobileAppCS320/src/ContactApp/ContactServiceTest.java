package ContactApp;
import static org.junit.jupiter.api.Assertions.*;

import org.juint.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class ContactServiceTest {
	protected String custId, testFirstName, testLastName, testPhoneNumber, testHomeAddress;
	protected String longCustId, longFirstName, longLastName, longPhoneNumber, shortPhoneNumber, longHomeAddress;
	
	@BeforeEach
	void setUp() {
		custId = "1234567890";
		testFirstName = "Jane";
		testLastName = "Doe";
		testPhoneNumber = "5555555555";
		testHomeAddress = "99 SNHU Way, BigCity, NH 15645";
		longCustId = "123456789456";
		longFirstName = "Jane Jamie Janet";
		longLastName = "Doe eyed deer";
		longPhoneNumber = "5554555658547";
		shortPhoneNumber = "5555555";
		longHomeAddress = "99 Southern New Hamshire University Way, Big City, New Hampshire, 15645";
				
	}
	
	@Test
	void newContactClassTest() {
		ContactService service = new ContactService();
		service.newContactClass();
		assertAll("service", () -> assertNotNull(service.getContactClassList().get(0).getCustId()),
				() -> assertEquals("Initial", service.getContactClassList().get(0).getFirstName()),
				() -> assertEquals("Initial", service.getContactClassList().get(0).getLastName()),
				() -> assertEquals("1234567789", service.getContactClassList().get(0).getPhoneNumber()),
				() -> assertEquals("Initial", service.getContactClassList().get(0).getHomeAddress()));
		service.newContactClass(testFirstName);
		assertAll("service", () -> assertNotNull(service.getContactClassList().get(1).getCustId()),
				() -> assertEquals(testFirstName, service.getContactClassList().get(1).getFirstName()),
				() -> assertEquals("Initial", service.getContactClassList().get(1).getLastName()),
				() -> assertEquals("1234567789", service.getContactClassList.get(1).getPhoneNumber()),
				() -> assertEquals("Initial", service.getContactClassList().get(1).getHomeAddress()));
		service.newContactClass(testFirstName, testLastName);
		ssertAll("service", () -> assertNotNull(service.getContactClassList().get(2).getCustId()),
				() -> assertEquals(testFirstName, service.getContactClassList().get(2).getFirstName()),
				() -> assertEquals(testLastName, service.getContactClassList().get(2).getLastName()),
				() -> assertEquals("1234567789", service.getContactClassList().get(2).getPhoneNumber()),
				() -> assertEquals("Initial", service.getContactClassList().get(2).getHomeAddress()));
		service.newContactClass(testFirstName, testLastName, testPhoneNumber);
		ssertAll("service", () -> assertNotNull(service.getContactClassList().get(3).getCustId()),
				() -> assertEquals(testFirstName, service.getContactClassList().get(3).getFirstName()),
				() -> assertEquals(testLastName, service.getContactClassList().get(3).getLastName()),
				() -> assertEquals(testPhoneNumber, service.getContactClassList().get(3).getPhoneNumber()),
				() -> assertEquals("Initial", service.getContactClassList().get(3).getHomeAddress()));
		service.newContactClass(testFirstName, testLastName, testPhoneNumber, testHomeAddress);
		ssertAll("service", () -> assertNotNull(service.getContactClassList().get(4).getCustId()),
				() -> assertEquals(testFirstName, service.getContactClassList().get(4).getFirstName()),
				() -> assertEquals(testLastName, service.getContactClassList().get(4).getLastName()),
				() -> assertEquals(testPhoneNumber, service.getContactClassList().get(4).getPhoneNumber()),
				() -> assertEquals(testHomeAddress, service.getContactClassList().get(4).getHomeAddress()));
		
	}
	
	@Test
	void deleteContactClassTest() {
		ContactService service = new ContactService();
		service.newContactClass();
		assertThrows(Exception.class, () -> service.deleteContactClass(custId));
		assertAll(() -> service.deleteContactClass(service.getContactClassList().get(0).getCustId()));
	
	}
	
	@Test
	void updateTestFirstName() throws Exception{
		ContactService service = new ContactService();
		service.newContactClass();
		service.updateFirstName(service.getContactClassList().get(0).getCustId(), testFirstName);
		assertEquals(testFirstName, service.getContactClassList().get(0).getFirstName());
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName(service.getContactClassList().get(0).getCustId(), longFirstName));
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName(service.getContactClassList().get(0).getCustId(), null));
		assertThrows(Exception.class, () -> service.updateFirstName(custId, testFirstName));
	}
	
	@Test
	void updateTestLastName() throws Exception{
		ContactService service = new ContactService();
		service.newContactClass();
		service.updatedLastName(service.getContactClassList().get(0).getCustId(), testLastName);
		assertThrows(IllegalArgumentException.class, () -> service.updateLastName(service.getContactClassList().get(0).getCustId(), longLastName));
		assertThrows(IllegalArgumentException.class, () -> service.updatedLastName(ervice.getContactClassList().get(0).getCustId(), null));
		assertThrows(Exception.class, () -> service.updateLastName(custId, testLastName));
		
	}
	
	@Test
	void updateTestPhoneNumber() throws Exception{
		ContactService service = new ContactService();
		service.newContactClass();
		service.updatePhoneNumber(service.getContactClassList().get(0).getCustId(), testPhoneNumber);
		assertEquals(testPhoneNumber, service.getContactClassList().get(0).getPhoneNumber());
		assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber(service.getContactClassList().get(0).getCustId(), longPhoneNumber));
		assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber(service.getContactClassList().get(0).getCustId(), shortPhoneNumber));
		assertThrows(IllegalArgumentException.class, () -> service.updatePHoneNumber(service.getContactClassList().get(0).getCustId(), null));
		assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber(custId, testPhoneNumber));
	}
	
	@Test
	void updateTestHomeAddress() throws Exception{
		ContactService service = new ContactService();
		service.newContactClass();
		service.updateHomeAddress(service.getContactClassList().get(0).getCustId(), testHomeAddress);
		assertEquals(testHomeAddress, service.getContactClassList().get(0).getHomeAddress());
		assertThrows(IllegalArgumentException.class, () -> service.updateHomeAddress(service.getContactClassList().get(0).getCustId(), longHomeAddress));
		assertThrows(IllegalArgumentException.class, () -> service.updateHomeAddress(service.getContactClassList().get(0).getCustId(), null));
		assertThrows(Exception.class, () -> service.updateHomeAddress(CustId, testHomeAddress));
			
	}
	
	
}
