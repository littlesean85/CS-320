package ContactApp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.juiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
	protected String custId, testFirstName, testLastName, testPhoneNumber, testHomeAddress;
	protected String longCustId, longFirstName, longLastName, longPhoneNumber, shortPhoneNumber, longHomeAddress;
	
	@BeforeEach
	void setUp() {
		custId = "1234567890";
		testFirstName = "Jane";
		testLastName = "Doe";
		testPhoneNumber = "5555555555";
		testHomeAddress = "99 SNHU Way, BigCity, NH 15645";
		longCustId = "123456789456";
		longFirstName = "Jane Jamie Janet";
		longLastName = "Doe eyed deer";
		longPhoneNumber = "5554555658547";
		shortPhoneNumber = "5555555";
		longHomeAddress = "99 Southern New Hamshire University Way, Big City, New Hampshire, 15645";
				
	}
	
	@Test
	void ContactClassTest() {
		ContactClass contactClass = new ContactClass();
		assertAll("constrctor", () -> assertNotNull(contactClass.getCustId()),
				() -> assertNotNull(contactClass.getFirstName()),
				() -> assertNotNull(contactClass.getLastName()),
				() -> assertNotNull(contactClass.getPhoneNumber()),
				() -> assertNotNUll(contactCLass.getHomeAddress()));
	}
	
	@Test
	void custIdConstructorTest() {
		ContactClass contactClass = new ContactClass(custId);
		assertAll("constructor 1", () -> assertEquals(custId, contactclass.getCustId()),
				() -> assertNotNull(contactClass.getFirstName()),
				() -> assertNotNull(contactClass.getLastName()),
				() -> assertNotNull(contactClass.getPhoneNumber()),
				() -> assertNotNull(contact.getHomeAddress()));
		
	}
	
	@Test
	void custIdFirstNameContructorTest() {
		ContactClass contactClass = new ContactClass(custId, testFirstName);
		assertAll("constructor 2", () -> assertEquals(custId, contactclass.getCustId()),
				() -> assertEquals(testFirstName, contactClass.getFirstName()),
				() -> assertNotNull(contactClass.getLastName()),
				() -> assertNotNull(contactClass.getPhoneNumber()),
				() -> assertNotNull(contact.getHomeAddress()));
	}
	
	@Test
	void custIdFirstLastNameConstructorTest() {
		ContactClass contactClass = new ContactClass(custId, testFirstName, testLastName);
		assertAll("constructor 3", () -> assertEquals(custId, contactclass.getCustId()),
				() -> assertEquals(testFirstName, contactClass.getFirstName()),
				() -> assertEquals(testLastName, contactClass.getLastName()),
				() -> assertNotNull(contactClass.getPhoneNumber()),
				() -> assertNotNull(contact.getHomeAddress()));
	}
	
	@Test
	void custIDFirstLastNamePhoneNumberConstructorTest() {
		ContactClass contactClass = new ContactClass(custId, testFirstName, testLastName, testPhoneNumber);
		assertAll("constructor 4", () -> assertEquals(custId, contactclass.getCustId()),
				() -> assertEquals(testFirstName, contactClass.getFirstName()),
				() -> assertEquals(testLastName, contactClass.getLastName()),
				() -> assertEquals(testPhoneNumber, contactClass.getPhoneNumber()),
				() -> assertNotNull(contact.getHomeAddress()));
	}
	
	@Test
	void custIDFirstLastNamePhoneNumberHomeAddressConstructorTest() {
		assertAll("constructor 5", () -> assertEquals(custId, contactclass.getCustId()),
				() -> assertEquals(testFirstName, contactClass.getFirstName()),
				() -> assertEquals(testLastName, contactClass.getLastName()),
				() -> assertEquals(testPhoneNumber, contactClass.getPhoneNumber()),
				() -> assertEquals(testHomeAddress.getHomeAddress()));
	}
	
	@Test
	void updateTestFirstName() {
		ContactClass contactClass = new ContactClass();
		contactClass.updateTestFirstName(testFirstName);
		assertAll("First Name", () -> assertEquals(testFirstName, contactClass.getFirstName()),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateFirstName(null)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateFirstName(longFirstName)));
		
	}
	
	@Test
	void updateTestLastName() {
		ContactClass contactClass = new ContactClass();
		contactClass.updateLastName(testLastName);
		assertAll("Last Name", () -> assertEquals(testLastName, contact.getLastName()),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateLastName(null)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateLastName(longLastName)));
		
	}
	
	@Test
	void updateTestPhoneNumber() {
		ContactClass contactClass = new ContactClass();
		contactClass.updatePhoneNumber(testPhoneNumber);
		assertAll("Phone Number", () -> assertEquals(testPhoneNumber, contact.getPhoneNumber()),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updatePhoneNumber(null)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updatePhoneNumber(longPhoneNumber)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updatePhoneNumber(shortPhoneNumber)));
	}
	
	@Test
	void updateTestHomeAddress() {
		ContactClass contactClass = new ContactClass();
		contactClass.updateHomeAddress(testHomeAddress);;
		assertAll("Home Address", () -> assertEquals(testHomeAddress, contact.getHomeAddress()),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass. updatedHomeAddress(null)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateHomeAddress(longHomeAddress)));
		
	}
	
	@Test
	void updateTestCustId() {
		ContactClass contactClass = new ContactClass();
		contactClass.updateCustId(custId);
		assertAll("Customer ID", () -> assertEquals(custId, contactClass.getCustId()),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateCustId(null)),
				() -> assertThrows(IllegalArgumentException.class, () -> contactClass.updateCustId(longCustId)));
	}
}
