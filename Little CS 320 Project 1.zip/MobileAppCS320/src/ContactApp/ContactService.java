package ContactApp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactService {
	
	private String uniqueCustId;
	private List<ContactClass> contactClassList = new ArrayList<>();
	
	{
		uniqueCustId = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	public void newContactClass() {
		ContactClass contactClass = new ContactClass(uniqueCustId());
		contactClassList.add(contactClass);
	}
	
	public void newContactClass(String firstName) {
		ContactClass contactClass = new ContactClass(uniqueCustId(), firstName);
		contactClassList.add(contactClass);
	}
	
	public void newContactClass(String firstName, String lastName) {
		ContactClass contactClass = new ContactClass(uniqueCustId(), firstName, lastName);
		contactClassList.add(contactClass);
	}
	
	public void newContactClass(String firstName, String lastName, String phoneNumber) {
		ContactClass contactClass = new ContactClass(uniqueCustId(), firstName, lastName, phoneNumber);
		contactClassList.add(contactClass);
	}
	
	public void newContactClass(String firstName, String lastName, String phoneNumber, String homeAddress) {
		ContactClass contactClass = new ContactClass(uniqueCustId(), firstName, lastName, phoneNumber, homeAddress);
		contactClassList.add(contactClass);
	}
	
	public void deleteContactClass(String custId) throws Exception{
		contactClassList.remove(searchForContact(custId));
	}
	
	public void updateFirstName(String custId, String firstName) throws Exception{
		searchForContactClass(custId).updateFirstName(firstName);
	}
	
	public void updateLastName(String custId, String lastName) throws Exception{
		searchForContactClass(custId).updateLastName(lastName);
	}
	
	public void updatePhoneNumber(String custId, String phoneNumber) throws Exception{
		searchForContactClass(custId).updatePhoneNumber(phoneNumber);
	}
	
	public void updateHomeAddress(String custId, String homeAddress) throws Exception{
		searchForContactClass(custId).updateHomeAddress(homeAddress);
	}
	
	protected List<ContactClass> getContactClassList(){
		return contactClassList;
	}
	
	private String uniqueCustId() {
		return uniqueCustId = UUID.randomUUID().toString()substring(0, Math.min(toString().length(),10 ));
	}
	
	private ContactClass searchForContactClass(String custId) throws Exception{
		int index = 0;
		while(index < contactClassList.size()) {
			if(custId.equals(contactClassList.get(index).getCustId())) {
				return contactClassList.get(index);
			}
			
			index++;
		}
		
		throw new Exception("Task does not exisit.");
	}
	
}
