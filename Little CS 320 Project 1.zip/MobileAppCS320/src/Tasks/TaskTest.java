package Tasks;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class TaskTest {
	private String taskId, custName, description;
	private String longTaskId, longCustName, longDescription;
	
	@BeforeEach
	void setUp() {
		taskId = "0987654321";
		custName = "John Smith";
		description = "Description of the task object.";
		longTaskId = "12345678901234657890";
		longCustName = "John J. Smith The Third";
		longDescription = "This is a long description of the required object that we don't want to be longer than 50 characters.";
		
		
	}
	
	@Test
	void getTaskIdTest() {
		Task task = new Task(taskId);
		Assertions.assertEquals(taskId, task.getTaskId());
		
	}
	
	@Test
	void getCustNameTest() {
		task task = new Task(taskId, custName);
		Assertions.assertEquals(custName, task.getCustName());
		
	}
	
	@Test
	void getDescriptionTest() {
		Task task = new Task(taskId, custName, description);
		Assertion.assertEquals(description, task.getDescription());
		
	}
	
	@Test
	void setTaskId() {
		Task task = new Task();
		task.setTaskId(taskId);;
		Assertions.assertEquals(taskId, task.getTaskId());
		
	}
	
	@Test
	void setCustNameTest() {
		Task task = new Task();
		task.setCustName(custName);
		Assertions.assertEquals(custName, task.getCustName());
	}
	
	@Test
	void setDescriptionTest() {
		Task task = new Task();
		task.setDescription(description);;
		Assertions.assertEquals(description, task.getDescription());
		
		
	}
	
	@Test
	void setLongTaskIdTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(longTaskId));
		
	}
	
	@Test
	void setLongCustNameTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setCustName(longCustName));
		
	}
	
	@Test
	void setLongDescription() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setDescription(longDescription));
		
	}
	
	@Test
	void NullTaskIdTest() {
		Assertions.assertThros(IllegalArgumentException.class, () -> new Task(null));
		
	}
	
	@Test
	void NullCustNameTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setCustName(null));
		
	}
	
	@Test
	void NullDescriptionTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
		
	}

}
