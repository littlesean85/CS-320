package Tasks;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	
	private String taskId, custName, description;
	private String longCustName, longDescription;
	
	
	@BeforeEach
	void setUp() {
		taskId = "0987654321";
		custName = "John Smith";
		description = "Description of the task object.";
		longCustName = "John J. Smith The Third";
		longDescription = "This is a long description of the required object that we don't want to be longer than 50 characters.";
		
	}
	
	@Test
	void newTaskTest() {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertNotNull(service.getTaskList().get(0).getTaskId());
		Assertions.assertNotEquals("Id", service.getTaskList().get(0).getTaskId();
		
	}
	
	@Test
	void newTaskCustNameTest() {
		TaskService service = new TaskService();
		service.newTask(custName);
		Assertions.assertNotNull(service.getTaskList().get(0).getCustName());
		Assertions.assertEquals(custName, service.getTaskList().get(0).getCustName());
		
	}
	
	@Test
	void newTaskDescriptionTest() {
		TaskService service = new TaskService();
		service.newTask(custName, description);
		Assertions.assertNotNull(service.getTaskList().get(0).getDescription))):
		Assertions.assertEquals(description, service.getTaskList().get(0).getDescription());
		
	}
	
	@Test
	void newTaskNullNameTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.newTask(null));
		
	}
	
	@Test
	void newTaskNullDescriptionTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.NewTask(null)));
		
	}
	
	@Test
	void newTaskLongCustNameTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(longCustName)):
			
	}
	
	@Test
	void newTaskLongDescription() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(custName, longDescription));
		
	}
	
	@Test
	void deleteTaskTest() throws Exception {
		TaskService service = new TaskService();
		Service.newTask();
		assertEquals(1, service.getTaskList().size());
		service.deleteTask(service.getTaskList().get(0).getTaskId());
		assertEquals(0, service.getTaskList().size());
		
	}
	
	@Test
	void deleteTaskNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertEquals(1, service.getTaskList().size());
		asertThrows(Exception.class, () -> service.deleteTask(taskId));
		assertEquals(1, service.getTaskList().size());
		
	}
	
	@Test
	void updateCustNameTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateCustName(service.getTaskList().get(0).getTaskId(), custName);
		assertEquals(custName, service.getTaskList().get(0).getCustName());
		
	}
	
	@Test
	void updateDescriptionTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateDescription(service.getTaskList().get(0).getTaskId(), description);
		assertEquals(description, service.getTaskList().get(0).getDescription()):
			
	}
	
	@Test
	void updateCustNameNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updateCustName(taskId, custName));
		
	}
	
	@Test
	void updateDescriptionNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updatedescription(taskId, description));
		
		
	}
	
	@RepeatedTest(4)
	void UuidTest() {
		TaskService service = new TaskService();
		service.newTask();
		service.newTask();
		service.newTask();
		assertEquals(3, service.getTaskList().size());
		assertNotEquals(service.getTaskList().get(0).getTaskId(), service.getTaskList().get(1).getTaskId());
		assertNotEquals(service.getTaskList().get(0).getTaskId(), service.getTaskList().get(2).getTaskId());
		assertNotEquals(service.getTaskList().get(1).getTaskId(), service.getTaskList().get(2).getTaskId());
		
	}

}
