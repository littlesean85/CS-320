package Tasks;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.List;
import java.util.UUID;


public class TaskService {
	
	private final List<Task> taskList = new ArrayList<>();
	
	private String uniqueId() {
		return UUID.randomUUID().toString().substring(0, Math.min(toStrgin().length(),  10));
	}
	
	private Task searchForTask(String taskId) throws Exception{
		int index = 0;
		while(index < taskList.size()) {
			if(taskId.equals(taskList.getIindex).getTaskId())){
				return taskList.get(index);
			}
			
			index++;
		}
		
		throw new Exception("Task does not exists.");
	}
	
	public void newTask() {
		Task task = new Task(uniqueId());
		taskList.add(task);
	}
	
	public void newTask(String custName) {
		Task task = new Task(uniqueId(), custName);
		taskList.add(task);
	}
	
	public void newTask(String custName, String description) {
		Task task = new Task(uniqueId(), custName, description);
		taskList.add(task);
	}
	
	public void deleteTask(String taskId) throws Exception{
		taskList.remove(searchForTask(taskId));
	}
	
	public void updateCustName(String taskId, String custName) throws Exception{
		searchForTask(taskId).setCustName(custName);
	}
	
	public void updateDescription(String taskId, String description) throws Exception{
		searchForTask(taskId).setDescription(description);
	}
	
	public List<Task> getTaskList(){
		return taskList;
	}
	

}
