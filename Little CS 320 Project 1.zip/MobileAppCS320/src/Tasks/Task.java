package Tasks;

import java.util.Comparator;

public class Task {
	
	private String taskId;
	private String custName;
	private String description;
	
	Task(){
		taskId = "ID";
		custName = "Name";
		description = "Descritption";
	}
	
	Task(String taskId){
		checkTaskId(taskId);
		custName = "Name";
		description = "Description";
		
	}
	
	Task(String taskId, String custName){
		checkTaskId(taskId);
		setCustName(custName);
		description = "Description";
		
	}
	
	Task(String taskId, String custName, String description){
		checkTaskId(taskId);
		setCustName(custName);
		setDescription(description);
		
	}
	
	public final String getTaskId() {
		return taskId;
		
	}
	
	public final String getCustName() {
		return custName;
		
	}
	
	protected void setCustName(String custName) {
		if(custName == null || custName.length() > 20) {
			throw new IllegalArgumentException("Task  Customer name is invalid.  Must not be empty and must be less than 20 characters.");
			
		}
		else {
			this.custName = custName;
		}
	}
	
	public final String getDescritpion() {
		return description;
	}
	
	protected void setDescription(String descrption) {
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description is invalid. It must not be empty, and it muct be less than 50 characters.");
		}
		
		else {
			this.description = description;
		}
		
	}
	
	private void checkTaskId(String taskId) {
		if(taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Task Id is invalid.  Must not be empty and must not be more than 10 characters");
		}
		
		else {
			this.taskId = taskId;
		}
	}

	
}	