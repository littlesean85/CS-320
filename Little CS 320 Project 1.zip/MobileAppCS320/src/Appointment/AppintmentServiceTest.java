package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppintmentServiceTest {
	private String appointmentId, appointmentDescription, longAppointmentDescription;
	private Date appointmentDate, pastDate;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setup() {
		appointmentId = "1234567890";
		appointmentDescription = "Required Description listed here.";
		appointmentDate = new Date(2022, Calendar.MAY, 12);
		longAppointmentId = "12345678901234567890";
		longAppointmentDescription = "Requried description is too long for required set up, but that is for testing purposes only.";
		pastDate = new Date(0);
				
	}
	
	@Test
	void testNewAppointment() {
		AppointmentService service = new AppointmentService();
		
		service.newAppointment();
		assertNotNull(service.getAppointmentList().get(0).getAppointmentId());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDescription());
		
		service.newAppointment(appointmentDate);
		assertNotNull(service.getAppointmentList().get(1).getAppointmentId());
		assertEquals(appointmentDate, service.getAppointmentList().get(2).getAppointmentDate());
		assertEquals(appointmentDescription, service.getAppointmentList().get(2).getAppointmentDescription());
		
		assertNotEquals(service.getAppointmetList().get(0).getAppointmentId(), service.getAppointmentList().get(1).getAppointmentId());
		assertNotEquals(service.getAppointment().get(0).getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());
		assertNotEquals(service.getAppointmentList().get(1)getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());
		
		assertThrows(IllegalArgumentException.class, () -> service.newAppointment(pastDate));
		assertThrows(IllegalArgumentException.class, () -> service.newAppointment(appointmentDate, longAppointmentDescription));
	}
	
	@Test
	void deleteAppointment() throws Exception {
		AppointmentService service = new AppointmentService();
		
		service.newAppointment();
		service.newAppointment();
		service.newAppointment();
		
		String firstAppointmentId = service.getAppointmentList().get(0).getAppointmentId();
		String secondAppointmentId = service.getAppointmentList().get(1).getAppointmentId();
		String thirdAppointmentId = service.getAppointmentList().get(2).getAppointmentId();
		
		assertNotEquals(firstAppointmentId, secondAppointmentId);
		assertNotEquals(firstAppointmentId, thirdAppointmentId);
		assertNotEquals(secondAppointmentId, thirdAppointmentId);
		assertNotEquals(appointmentId, firstAppointmentId);
		assertNotEquals(appointmentId, secondAppointmentId);
		assertNotEquals(appointmentId, thirdAppointmentId);
		
		assertThrows(Exception.class, () -> service.deleteAppointment(appointmentId));
		
		service.deleteAppointment(firstAppointmentId);
		assertThrows(Exception.class, () -> service.deletedAppointment(firstAppointmentId));
		assertNotEquals(firstAppointmentId, service.getAppointmentList().get(0).getAppointmentId());
	}	

}
