package Appointment;

import java.util.Date;

public class Appointment {
	
	final private byte AppointmentIdLength;
	final private byte AppointmentDescriptionLength;
	final private String Initialize;
	private String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	
	{
		AppointmentIdLength = 10;
		AppointmentDescriptionLength = 50;
		Initialize = "Initial";
	}
	
	Appointment(){
		Date today = new Date();
		appointmentId = Initialize;
		appointmentDate = today;
		appointmentDescription = Initialize;
	
	}
	
	Appointment (String appointmentId){
		Date today = new Date();
		updateAppointmentId(appointmentId);
		appointmentDate = today;
		appointmentDescription = Initialize;
	}
	
	Appointment(String appointmentId, Date appointmentDate){
		updateAppointmentId(appointmentId);
		updateAppointmentDate(appointmentDate);
		updateAppointmentDescription(appointmentDescription);
	}
	
	public void updateAppointmentId(String appointmentId) {
		if (appointmentId == null) {
			throw new IllegalArgumentException("Appointment ID cannot be null.");
			
		}
		else if (appointmentId.length() > AppointmentIdLength) {
			throw new IllegalArgumentException("Appointment ID cannot exceed " + AppointmentIdLength + " characters.");
			
		}
		
		else {
			this.appointmentId = appointmentId;
		}
	}
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public void updateAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			throw new IllegalArgumentException("Appointment date cannot be null.");
			
		}
		
		else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment cannot be set in the past.");
			
		}
		
		else {
			this.appointmentDate = appointmentDate;
		}
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public void updateAppointmentDescription(String appointmentDescritption) {
		if (appointmentDescription == null) {
			throw new IllegalArgumentException("Appointment Description cannot be null.");
				
			
		}
		
		else if (appointmentDescription.length() > AppointmentDescriptionLength) {
			throw new IllegalArgumentException("Appointment description cannot exceed " + AppointmentDescriptionLength + " characters.");
			
		}
		
		else {
			this.appointmentDescription = appointmentDescription;
		}
	}
	
	public String getAppointmentDescripton() {
		return appointmentDescription;
		
	}

}
