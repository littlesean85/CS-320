package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
	
	private String appointmentId, appointmentDescription;
	private String longAppointmentId, longAppointmentDescription;
	private Date appointmentDate, pastDate;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setup() {
		appointmentId = "1234567890";
		appointmentDescription = "Required Description listed here.";
		appointmentDate = new Date(2022, Calendar.MAY, 12);
		longAppointmentId = "12345678901234567890";
		longAppointmentDescription = "Requried description is too long for required set up, but that is for testing purposes only.";
		pastDate = new Date(0);
				
	}
	
	@Test
	voidtestUpdateAppointmentId(){
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.updateAppointmentId(null));
		assertThrows(IllegalArgumentException.class, () -> appt.updateAppointmentId(longAppointmentId));
		appt.updateAppointmentId(appointmentId);
		assertEquals(appointmentId, appt.getAppointmentId());
		
			
	}
	
	@Test
	void testGetAppointmentId() {
		Appointment appt = new Appointment(appointmentId);
		assertNotNull(appt.getAppointmentId());
		assertEquals(appt.getAppointmentId().length(),10);
		assertEquals(appointmentId, appt.getAppointmentId());
		
	}
	
	@Test
	void testUpdateAppointmentDate() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.updateDate(null));
		assertThrows(IllegalArgumentException.class, () -> appt.updatedDate(pastDate));
		appt.updateAppointmentDate(appointmentDate);;
		assertEquals(appointmentDate, getAppointmentDate());
	}
	
	@Test
	void testUpdateAppointmentDescription() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArguentException.class, () -> appt.updateAppointmentDescription(null));
		assertThrows(IllegaglArgumentException.class, () -> appt.updateAppointmentDescription(longAppointmentDescription));
		appt.updateAppointmentDescription(appointmentDescription);
		assertEquals(appointmentDescription, appt.getAppointmentDescription());
		
	}
	
	@Test
	void testGetAppointmentDescription() {
		Appointment appt = new Appointment(appointmentId, appointmentDate, appointmentDescription);
		assertNotNull(appt.getAppointmentDescription());
		assertTrue(appt.getAppointmentDescription().length() <= 50);
		assertEquals(appointmentDescription, appt.getAppointmentDescription());
		
	}

}
